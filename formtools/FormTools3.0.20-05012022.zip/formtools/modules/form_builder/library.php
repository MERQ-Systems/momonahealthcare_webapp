<?php

require_once(__DIR__ . "/code/Forms.class.php");
require_once(__DIR__ . "/code/General.class.php");
require_once(__DIR__ . "/code/FormGenerator.class.php");
require_once(__DIR__ . "/code/Module.class.php");
require_once(__DIR__ . "/code/Placeholders.class.php");
require_once(__DIR__ . "/code/Resources.class.php");
require_once(__DIR__ . "/code/Templates.class.php");
require_once(__DIR__ . "/code/TemplateSets.class.php");
